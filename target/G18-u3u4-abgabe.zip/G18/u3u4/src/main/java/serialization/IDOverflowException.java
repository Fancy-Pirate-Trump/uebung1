package serialization;

public class IDOverflowException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = -1977807349887604157L;



}
